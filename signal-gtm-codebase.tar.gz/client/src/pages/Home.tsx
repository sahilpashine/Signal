import { useAuth } from "@/_core/hooks/useAuth";
import { getLoginUrl } from "@/const";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Link } from "wouter";
import {
  Zap, Target, MessageSquare, TrendingUp, BarChart3,
  ArrowRight, Check, ChevronRight, Sparkles, Brain,
  Users, Building2, Rocket, LineChart, Shield,
  Star, Play, Clock, Globe, Lock
} from "lucide-react";

// ─── Navbar ──────────────────────────────────────────────────────────────────
function Navbar() {
  const { isAuthenticated, user } = useAuth();
  return (
    <nav className="fixed top-0 left-0 right-0 z-50 glass border-b border-white/5">
      <div className="container flex items-center justify-between h-16">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-primary flex items-center justify-center glow-purple">
            <Zap className="w-4 h-4 text-white" />
          </div>
          <span className="font-bold text-lg tracking-tight text-white">Signal</span>
          <Badge variant="outline" className="text-xs border-primary/40 text-primary ml-1 hidden sm:flex">Beta</Badge>
        </div>
        <div className="hidden md:flex items-center gap-8 text-sm text-muted-foreground">
          <a href="#features" className="hover:text-white transition-colors">Features</a>
          <a href="#roadmap" className="hover:text-white transition-colors">Roadmap</a>
          <a href="#compare" className="hover:text-white transition-colors">Compare</a>
          <a href="#personas" className="hover:text-white transition-colors">Who It's For</a>
        </div>
        <div className="flex items-center gap-3">
          {isAuthenticated ? (
            <Link href="/app">
              <Button size="sm" className="bg-primary hover:bg-primary/90 text-white gap-2">
                <Sparkles className="w-3.5 h-3.5" />
                Open Signal
              </Button>
            </Link>
          ) : (
            <>
              <a href={getLoginUrl()} className="text-sm text-muted-foreground hover:text-white transition-colors hidden sm:block">Sign in</a>
              <a href={getLoginUrl()}>
                <Button size="sm" className="bg-primary hover:bg-primary/90 text-white gap-2">
                  Try Signal Free
                  <ArrowRight className="w-3.5 h-3.5" />
                </Button>
              </a>
            </>
          )}
        </div>
      </div>
    </nav>
  );
}

// ─── Hero ─────────────────────────────────────────────────────────────────────
function Hero() {
  const { isAuthenticated } = useAuth();
  return (
    <section className="relative min-h-screen flex items-center pt-16 overflow-hidden">
      {/* Background radial gradients */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute top-1/4 left-1/2 -translate-x-1/2 w-[800px] h-[600px] rounded-full"
          style={{ background: "radial-gradient(ellipse, oklch(0.62 0.22 270 / 0.12) 0%, transparent 70%)" }} />
        <div className="absolute bottom-0 left-1/4 w-[400px] h-[400px] rounded-full"
          style={{ background: "radial-gradient(ellipse, oklch(0.72 0.18 55 / 0.06) 0%, transparent 70%)" }} />
        {/* Grid pattern */}
        <div className="absolute inset-0 opacity-[0.03]"
          style={{ backgroundImage: "linear-gradient(oklch(0.97 0.005 240) 1px, transparent 1px), linear-gradient(90deg, oklch(0.97 0.005 240) 1px, transparent 1px)", backgroundSize: "60px 60px" }} />
      </div>

      <div className="container relative z-10">
        <div className="max-w-4xl mx-auto text-center">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full glass-light text-sm text-muted-foreground mb-8 animate-fade-up">
            <Sparkles className="w-3.5 h-3.5 text-primary" />
            AI-Powered GTM Intelligence for Product Marketers
            <ChevronRight className="w-3.5 h-3.5" />
          </div>

          <h1 className="text-5xl sm:text-6xl lg:text-7xl font-bold text-white mb-6 leading-[1.05] animate-fade-up" style={{ animationDelay: "0.1s", opacity: 0 }}>
            Your product deserves a{" "}
            <span className="text-gradient font-serif italic">world-class</span>{" "}
            GTM strategy
          </h1>

          <p className="text-lg sm:text-xl text-muted-foreground max-w-2xl mx-auto mb-10 leading-relaxed animate-fade-up" style={{ animationDelay: "0.2s", opacity: 0 }}>
            Signal thinks like a senior PMM and instantly generates everything you need to take any product to market — ICP, positioning, messaging, and competitive differentiation in seconds.
          </p>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 animate-fade-up" style={{ animationDelay: "0.3s", opacity: 0 }}>
            <a href={isAuthenticated ? "/app" : getLoginUrl()}>
              <Button size="lg" className="bg-primary hover:bg-primary/90 text-white gap-2 px-8 py-6 text-base glow-purple">
                <Zap className="w-4 h-4" />
                Generate Your GTM Brief
                <ArrowRight className="w-4 h-4" />
              </Button>
            </a>
            <a href="#features">
              <Button size="lg" variant="outline" className="gap-2 px-8 py-6 text-base border-white/10 text-white hover:bg-white/5">
                <Play className="w-4 h-4" />
                See How It Works
              </Button>
            </a>
          </div>

          <div className="flex items-center justify-center gap-8 mt-12 text-sm text-muted-foreground animate-fade-up" style={{ animationDelay: "0.4s", opacity: 0 }}>
            {[
              { icon: Clock, label: "Generates in < 30 seconds" },
              { icon: Shield, label: "No credit card required" },
              { icon: Star, label: "Built for PMMs" },
            ].map(({ icon: Icon, label }) => (
              <div key={label} className="flex items-center gap-1.5">
                <Icon className="w-3.5 h-3.5 text-primary" />
                <span>{label}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Hero visual — mock GTM brief card */}
        <div className="mt-20 max-w-5xl mx-auto animate-fade-up" style={{ animationDelay: "0.5s", opacity: 0 }}>
          <div className="glass rounded-2xl border border-white/8 overflow-hidden glow-purple">
            <div className="flex items-center gap-2 px-5 py-3 border-b border-white/8 bg-white/3">
              <div className="w-3 h-3 rounded-full bg-red-500/60" />
              <div className="w-3 h-3 rounded-full bg-yellow-500/60" />
              <div className="w-3 h-3 rounded-full bg-green-500/60" />
              <span className="ml-3 text-xs text-muted-foreground font-mono">signal — GTM Brief Generator</span>
            </div>
            <div className="p-6 grid grid-cols-1 sm:grid-cols-5 gap-4">
              {[
                { label: "ICP", color: "oklch(0.62 0.22 270)", icon: Users, preview: "B2B SaaS PMMs at Series A–C startups, 25–45, frustrated by slow GTM cycles" },
                { label: "Positioning", color: "oklch(0.72 0.18 55)", icon: Target, preview: "The only AI tool that thinks like a PMM, not just writes like one" },
                { label: "Value Props", color: "oklch(0.65 0.20 160)", icon: Zap, preview: "10x faster GTM briefs, PMM-structured output, zero prompt engineering" },
                { label: "Messaging", color: "oklch(0.60 0.22 320)", icon: MessageSquare, preview: "Email, LinkedIn, Landing page, Onboarding — all channels covered" },
                { label: "Competitive Diff", color: "oklch(0.68 0.18 200)", icon: TrendingUp, preview: "Strategy-first, not just content. Connects to data, not just text" },
              ].map(({ label, color, icon: Icon, preview }) => (
                <div key={label} className="rounded-xl p-4 border border-white/6" style={{ background: `${color.replace(")", " / 0.08)")}` }}>
                  <div className="flex items-center gap-2 mb-2">
                    <Icon className="w-3.5 h-3.5" style={{ color }} />
                    <span className="text-xs font-semibold" style={{ color }}>{label}</span>
                  </div>
                  <p className="text-xs text-muted-foreground leading-relaxed">{preview}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

// ─── Problem Section ──────────────────────────────────────────────────────────
function Problem() {
  return (
    <section className="py-24 relative overflow-hidden">
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute top-1/2 right-0 w-[500px] h-[500px] rounded-full"
          style={{ background: "radial-gradient(ellipse, oklch(0.72 0.18 55 / 0.05) 0%, transparent 70%)" }} />
      </div>
      <div className="container relative z-10">
        <div className="max-w-3xl mx-auto text-center mb-16">
          <Badge variant="outline" className="border-destructive/40 text-destructive mb-4">The Problem</Badge>
          <h2 className="text-4xl sm:text-5xl font-bold text-white mb-6">
            GTM strategy shouldn't take{" "}
            <span className="text-gradient-purple font-serif italic">days</span>
          </h2>
          <p className="text-lg text-muted-foreground">
            When a PMM joins a new company or gets assigned a new product, the manual work is exhausting — and it delays everything.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-5xl mx-auto">
          {[
            { title: "Market Research", time: "4–8 hours", desc: "Manually scanning competitors, reading analyst reports, synthesizing market data" },
            { title: "ICP Definition", time: "2–4 hours", desc: "Interviewing stakeholders, reviewing CRM data, building customer profiles from scratch" },
            { title: "Positioning Work", time: "3–6 hours", desc: "Workshopping statements, aligning with leadership, iterating on frameworks" },
            { title: "Messaging Creation", time: "4–8 hours", desc: "Writing copy for every channel, adapting tone, reviewing with design and sales" },
            { title: "Competitive Analysis", time: "3–5 hours", desc: "Manually reviewing competitor sites, G2 reviews, and sales call recordings" },
            { title: "GTM Brief Assembly", time: "2–4 hours", desc: "Pulling everything into a coherent document that stakeholders can actually use" },
          ].map(({ title, time, desc }) => (
            <div key={title} className="glass rounded-xl p-5 border border-white/6 hover:border-white/12 transition-colors group">
              <div className="flex items-start justify-between mb-3">
                <span className="text-sm font-semibold text-white">{title}</span>
                <Badge variant="outline" className="text-xs border-destructive/40 text-destructive shrink-0 ml-2">{time}</Badge>
              </div>
              <p className="text-sm text-muted-foreground leading-relaxed">{desc}</p>
            </div>
          ))}
        </div>

        <div className="mt-12 text-center">
          <div className="inline-flex items-center gap-3 glass rounded-2xl px-8 py-5 border border-primary/20">
            <Clock className="w-5 h-5 text-destructive" />
            <span className="text-white font-semibold">Total: 18–35 hours per product launch</span>
            <ArrowRight className="w-4 h-4 text-muted-foreground" />
            <Zap className="w-5 h-5 text-primary" />
            <span className="text-primary font-semibold">Signal: Under 30 seconds</span>
          </div>
        </div>
      </div>
    </section>
  );
}

// ─── Features / Output Table ──────────────────────────────────────────────────
function Features() {
  const outputs = [
    {
      icon: Users,
      label: "ICP",
      color: "oklch(0.62 0.22 270)",
      title: "Ideal Customer Profile",
      why: "Foundation of all marketing",
      what: "Who your ideal customer is, their pain points, what they care about, and demographic/firmographic signals",
      example: "B2B SaaS PMMs at Series A–C companies, 28–42, frustrated by the gap between product launches and market readiness",
    },
    {
      icon: Target,
      label: "Positioning",
      color: "oklch(0.72 0.18 55)",
      title: "Positioning Statement",
      why: "Goes on landing pages, decks, pitches",
      what: "One crisp, defensible sentence defining the product's unique market position",
      example: "For PMMs who need to move fast, Signal is the only AI tool that thinks strategically about GTM — not just writes copy",
    },
    {
      icon: Zap,
      label: "Value Props",
      color: "oklch(0.65 0.20 160)",
      title: "Value Propositions",
      why: "Used in ads, emails, sales calls",
      what: "Top 3 reasons customers should buy, each with a clear, benefit-led headline and supporting detail",
      example: "1. 10x faster GTM briefs  2. PMM-structured, not generic  3. Zero prompt engineering required",
    },
    {
      icon: MessageSquare,
      label: "Messaging",
      color: "oklch(0.60 0.22 320)",
      title: "Messaging by Channel",
      why: "Ready to copy-paste into campaigns",
      what: "Email subject line, LinkedIn ad copy, landing page hero, and onboarding message — all tailored to your product",
      example: "Email: 'Your next GTM brief in 30 seconds' | LinkedIn: 'PMMs: stop spending days on briefs' | Hero: 'GTM strategy at the speed of thought'",
    },
    {
      icon: TrendingUp,
      label: "Competitive Diff",
      color: "oklch(0.68 0.18 200)",
      title: "Competitive Differentiation",
      why: "Used in battlecards, sales enablement",
      what: "What makes this product uniquely valuable versus alternatives, with specific, defensible differentiators",
      example: "Unlike ChatGPT, Signal applies PMM frameworks. Unlike Jasper, Signal connects messaging to strategy. Unlike Crayon, Signal tells you what to do.",
    },
  ];

  return (
    <section id="features" className="py-24 relative">
      <div className="container">
        <div className="max-w-3xl mx-auto text-center mb-16">
          <Badge variant="outline" className="border-primary/40 text-primary mb-4">What Signal Generates</Badge>
          <h2 className="text-4xl sm:text-5xl font-bold text-white mb-6">
            A complete GTM brief,{" "}
            <span className="text-gradient font-serif italic">structured perfectly</span>
          </h2>
          <p className="text-lg text-muted-foreground">
            Every section is purpose-built for how PMMs actually work. Not generic AI output — a real GTM brief you can use immediately.
          </p>
        </div>

        <div className="space-y-4 max-w-5xl mx-auto">
          {outputs.map(({ icon: Icon, label, color, title, why, what, example }) => (
            <div key={label} className="glass rounded-2xl border border-white/6 hover:border-white/12 transition-all duration-300 overflow-hidden group">
              <div className="flex flex-col lg:flex-row">
                {/* Left: label */}
                <div className="lg:w-48 p-6 flex lg:flex-col items-center lg:items-start gap-4 lg:gap-3 border-b lg:border-b-0 lg:border-r border-white/6"
                  style={{ background: `${color.replace(")", " / 0.06)")}` }}>
                  <div className="w-10 h-10 rounded-xl flex items-center justify-center shrink-0"
                    style={{ background: `${color.replace(")", " / 0.15)")}`, border: `1px solid ${color.replace(")", " / 0.30)")}` }}>
                    <Icon className="w-5 h-5" style={{ color }} />
                  </div>
                  <div>
                    <div className="text-xs font-bold uppercase tracking-widest mb-0.5" style={{ color }}>{label}</div>
                    <div className="text-sm font-semibold text-white">{title}</div>
                  </div>
                </div>
                {/* Middle: what + why */}
                <div className="flex-1 p-6 grid grid-cols-1 sm:grid-cols-2 gap-6">
                  <div>
                    <div className="text-xs text-muted-foreground uppercase tracking-wider mb-2">What it is</div>
                    <p className="text-sm text-white/80 leading-relaxed">{what}</p>
                  </div>
                  <div>
                    <div className="text-xs text-muted-foreground uppercase tracking-wider mb-2">Example output</div>
                    <p className="text-sm text-muted-foreground leading-relaxed italic">{example}</p>
                  </div>
                </div>
                {/* Right: why it matters */}
                <div className="lg:w-44 p-6 flex lg:flex-col justify-center border-t lg:border-t-0 lg:border-l border-white/6">
                  <div className="text-xs text-muted-foreground uppercase tracking-wider mb-1 hidden lg:block">Why it matters</div>
                  <Badge variant="outline" className="text-xs w-fit" style={{ borderColor: `${color.replace(")", " / 0.40)")}`, color }}>{why}</Badge>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

// ─── Roadmap ──────────────────────────────────────────────────────────────────
function Roadmap() {
  const versions = [
    {
      v: "V1",
      name: "GTM Brief Generator",
      status: "live",
      color: "oklch(0.62 0.22 270)",
      icon: Zap,
      desc: "Describe any product. Get a complete GTM brief — ICP, positioning, value props, channel messaging, and competitive differentiation — in under 30 seconds.",
      features: ["ICP Analysis", "Positioning Statement", "Value Propositions", "Channel Messaging", "Competitive Diff"],
    },
    {
      v: "V2",
      name: "Churn Narrative Engine",
      status: "soon",
      color: "oklch(0.72 0.18 55)",
      icon: BarChart3,
      desc: "Upload a CSV of user behavioral data. Signal tells you why users churned in plain English, then automatically rewrites your onboarding messaging to fix it.",
      features: ["CSV Upload", "Churn Reason Analysis", "Onboarding Rewrite", "Retention Playbook"],
    },
    {
      v: "V3",
      name: "Competitive Pulse Engine",
      status: "planned",
      color: "oklch(0.65 0.20 160)",
      icon: Globe,
      desc: "Input your competitors. Signal searches the web live, tells you what changed this week, and gives you a concrete action plan to respond.",
      features: ["Live Web Search", "Weekly Diff Reports", "Action Recommendations", "Battlecard Updates"],
    },
    {
      v: "V4",
      name: "Launch War Room",
      status: "planned",
      color: "oklch(0.60 0.22 320)",
      icon: Rocket,
      desc: "Input your launch date and feature. Signal generates a full reverse-engineered GTM timeline with KPIs, channel plan, and risk flags.",
      features: ["Launch Timeline", "KPI Framework", "Channel Plan", "Risk Flags"],
    },
    {
      v: "V5",
      name: "The Full Signal Platform",
      status: "vision",
      color: "oklch(0.68 0.18 200)",
      icon: Brain,
      desc: "All 4 engines in one unified dashboard. Your complete AI PMM co-pilot — from positioning to launch to retention to competitive intelligence.",
      features: ["Unified Dashboard", "All 4 Engines", "Team Collaboration", "API Access"],
    },
  ];

  const statusConfig: Record<string, { label: string; class: string }> = {
    live: { label: "Live Now", class: "border-green-500/40 text-green-400" },
    soon: { label: "Coming Soon", class: "border-yellow-500/40 text-yellow-400" },
    planned: { label: "Planned", class: "border-primary/40 text-primary" },
    vision: { label: "Vision", class: "border-muted-foreground/40 text-muted-foreground" },
  };

  return (
    <section id="roadmap" className="py-24 relative overflow-hidden">
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute top-1/2 left-0 w-[600px] h-[600px] rounded-full -translate-y-1/2"
          style={{ background: "radial-gradient(ellipse, oklch(0.62 0.22 270 / 0.06) 0%, transparent 70%)" }} />
      </div>
      <div className="container relative z-10">
        <div className="max-w-3xl mx-auto text-center mb-16">
          <Badge variant="outline" className="border-primary/40 text-primary mb-4">Product Roadmap</Badge>
          <h2 className="text-4xl sm:text-5xl font-bold text-white mb-6">
            Signal is just{" "}
            <span className="text-gradient font-serif italic">getting started</span>
          </h2>
          <p className="text-lg text-muted-foreground">
            V1 is the GTM Brief Generator. But Signal is being built to become the complete AI PMM co-pilot.
          </p>
        </div>

        <div className="relative max-w-4xl mx-auto">
          {/* Timeline line */}
          <div className="absolute left-8 top-0 bottom-0 w-px bg-gradient-to-b from-primary/60 via-primary/20 to-transparent hidden lg:block" />

          <div className="space-y-6">
            {versions.map(({ v, name, status, color, icon: Icon, desc, features }) => (
              <div key={v} className="flex gap-6 group">
                {/* Timeline node */}
                <div className="hidden lg:flex flex-col items-center shrink-0">
                  <div className="w-16 h-16 rounded-2xl flex items-center justify-center border transition-all duration-300"
                    style={{
                      background: status === "live" ? `${color.replace(")", " / 0.15)")}` : "oklch(0.14 0.018 260)",
                      borderColor: status === "live" ? color : "oklch(0.22 0.020 260)",
                    }}>
                    <Icon className="w-6 h-6" style={{ color: status === "live" ? color : "oklch(0.45 0.015 260)" }} />
                  </div>
                </div>
                {/* Card */}
                <div className="flex-1 glass rounded-2xl border border-white/6 hover:border-white/12 p-6 transition-all duration-300">
                  <div className="flex flex-wrap items-start justify-between gap-3 mb-4">
                    <div className="flex items-center gap-3">
                      <div className="lg:hidden w-10 h-10 rounded-xl flex items-center justify-center"
                        style={{ background: `${color.replace(")", " / 0.15)")}`, border: `1px solid ${color.replace(")", " / 0.30)")}` }}>
                        <Icon className="w-5 h-5" style={{ color }} />
                      </div>
                      <div>
                        <div className="text-xs font-bold uppercase tracking-widest mb-0.5" style={{ color }}>{v}</div>
                        <h3 className="text-lg font-bold text-white">{name}</h3>
                      </div>
                    </div>
                    <Badge variant="outline" className={`text-xs ${statusConfig[status].class}`}>{statusConfig[status].label}</Badge>
                  </div>
                  <p className="text-sm text-muted-foreground leading-relaxed mb-4">{desc}</p>
                  <div className="flex flex-wrap gap-2">
                    {features.map((f) => (
                      <span key={f} className="text-xs px-2.5 py-1 rounded-full border border-white/8 text-muted-foreground">{f}</span>
                    ))}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

// ─── Comparison Table ─────────────────────────────────────────────────────────
function Compare() {
  const tools = [
    { name: "ChatGPT", does: "Generates content if you prompt it perfectly", missing: "No PMM structure, no memory, you do all the thinking" },
    { name: "Jasper / Copy.ai", does: "Writes marketing copy", missing: "Not connected to strategy or data" },
    { name: "Crayon / Klue", does: "Tracks competitor changes", missing: "Just tracking — no 'so what', costs $2K+/month" },
    { name: "Notion AI", does: "Summarizes docs", missing: "Not built for GTM workflows" },
  ];

  const features = [
    "PMM-structured output",
    "Strategy-first (not just copy)",
    "ICP + Positioning + Messaging",
    "Competitive intelligence",
    "Ready to use in < 1 minute",
    "Built for product launches",
    "Affordable for individuals",
  ];

  return (
    <section id="compare" className="py-24 relative">
      <div className="container">
        <div className="max-w-3xl mx-auto text-center mb-16">
          <Badge variant="outline" className="border-primary/40 text-primary mb-4">Why Signal</Badge>
          <h2 className="text-4xl sm:text-5xl font-bold text-white mb-6">
            Nothing else thinks like{" "}
            <span className="text-gradient font-serif italic">a PMM</span>
          </h2>
          <p className="text-lg text-muted-foreground">
            Every other tool either writes content or tracks data. Signal is the first tool built to think strategically about go-to-market.
          </p>
        </div>

        {/* Comparison cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 max-w-4xl mx-auto mb-12">
          {tools.map(({ name, does, missing }) => (
            <div key={name} className="glass rounded-xl p-5 border border-white/6">
              <div className="flex items-center gap-2 mb-3">
                <div className="w-2 h-2 rounded-full bg-muted-foreground/40" />
                <span className="font-semibold text-white text-sm">{name}</span>
              </div>
              <div className="space-y-2">
                <div className="flex gap-2 text-sm">
                  <Check className="w-4 h-4 text-green-400 shrink-0 mt-0.5" />
                  <span className="text-muted-foreground">{does}</span>
                </div>
                <div className="flex gap-2 text-sm">
                  <span className="text-destructive shrink-0 mt-0.5 font-bold">✕</span>
                  <span className="text-muted-foreground">{missing}</span>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Signal wins */}
        <div className="max-w-4xl mx-auto glass rounded-2xl border border-primary/20 p-8 glow-purple">
          <div className="flex items-center gap-3 mb-6">
            <div className="w-10 h-10 rounded-xl bg-primary/15 border border-primary/30 flex items-center justify-center">
              <Zap className="w-5 h-5 text-primary" />
            </div>
            <div>
              <div className="text-xs text-primary font-bold uppercase tracking-widest">Signal</div>
              <div className="text-lg font-bold text-white">Thinks like a PMM, not just writes like one</div>
            </div>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
            {features.map((f) => (
              <div key={f} className="flex items-center gap-2 text-sm">
                <div className="w-5 h-5 rounded-full bg-primary/15 border border-primary/30 flex items-center justify-center shrink-0">
                  <Check className="w-3 h-3 text-primary" />
                </div>
                <span className="text-white/80">{f}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

// ─── User Personas ────────────────────────────────────────────────────────────
function Personas() {
  const personas = [
    {
      role: "PMM at a Startup",
      icon: Rocket,
      color: "oklch(0.62 0.22 270)",
      useCase: "Instant GTM brief for every new feature launch",
      pain: "Constantly launching features without time to build proper GTM strategy",
      gain: "Ship with a complete brief in the time it used to take to open a Notion doc",
      quote: "I used to spend a full day on positioning. Now I have a brief before my first coffee.",
    },
    {
      role: "Marketing Consultant",
      icon: LineChart,
      color: "oklch(0.72 0.18 55)",
      useCase: "Generate client briefs in minutes, not days",
      pain: "Onboarding new clients requires massive upfront research and strategy work",
      gain: "Deliver a polished GTM brief in the first client meeting, not two weeks later",
      quote: "Signal pays for itself on the first client engagement. It's embarrassingly good.",
    },
    {
      role: "Founder",
      icon: Brain,
      color: "oklch(0.65 0.20 160)",
      useCase: "Figure out positioning before hiring a PMM",
      pain: "No marketing expertise in-house, but need to go to market with confidence",
      gain: "Get PMM-quality positioning and messaging without the $150K hire",
      quote: "This is what I needed before my Series A pitch. Positioning finally makes sense.",
    },
    {
      role: "Sales Team",
      icon: TrendingUp,
      color: "oklch(0.60 0.22 320)",
      useCase: "Understand product messaging instantly",
      pain: "Marketing briefs are always late, incomplete, or too abstract to use in calls",
      gain: "Get clear, channel-ready messaging and competitive differentiators on demand",
      quote: "I finally understand what makes us different. My close rate went up immediately.",
    },
    {
      role: "Marketing Agency",
      icon: Building2,
      color: "oklch(0.68 0.18 200)",
      useCase: "Onboard new clients 10x faster",
      pain: "Every new client requires weeks of discovery before any real work can begin",
      gain: "Run a Signal brief in the discovery call and start strategy work immediately",
      quote: "We now deliver strategy in week one instead of week four. Clients love it.",
    },
  ];

  return (
    <section id="personas" className="py-24 relative overflow-hidden">
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute bottom-0 right-1/4 w-[500px] h-[400px] rounded-full"
          style={{ background: "radial-gradient(ellipse, oklch(0.62 0.22 270 / 0.06) 0%, transparent 70%)" }} />
      </div>
      <div className="container relative z-10">
        <div className="max-w-3xl mx-auto text-center mb-16">
          <Badge variant="outline" className="border-primary/40 text-primary mb-4">Who Uses Signal</Badge>
          <h2 className="text-4xl sm:text-5xl font-bold text-white mb-6">
            Built for everyone who needs{" "}
            <span className="text-gradient font-serif italic">GTM clarity</span>
          </h2>
          <p className="text-lg text-muted-foreground">
            Whether you're a seasoned PMM or a founder figuring out positioning for the first time, Signal meets you where you are.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-6xl mx-auto">
          {personas.map(({ role, icon: Icon, color, useCase, pain, gain, quote }) => (
            <div key={role} className="glass rounded-2xl border border-white/6 hover:border-white/12 p-6 transition-all duration-300 group flex flex-col">
              <div className="flex items-center gap-3 mb-4">
                <div className="w-10 h-10 rounded-xl flex items-center justify-center shrink-0"
                  style={{ background: `${color.replace(")", " / 0.15)")}`, border: `1px solid ${color.replace(")", " / 0.30)")}` }}>
                  <Icon className="w-5 h-5" style={{ color }} />
                </div>
                <div>
                  <div className="text-xs font-bold uppercase tracking-widest mb-0.5" style={{ color }}>Use Case</div>
                  <h3 className="text-sm font-bold text-white">{role}</h3>
                </div>
              </div>
              <p className="text-sm font-medium text-white/90 mb-4">{useCase}</p>
              <div className="space-y-2 mb-5 flex-1">
                <div className="flex gap-2 text-xs">
                  <span className="text-destructive shrink-0 font-bold mt-0.5">✕</span>
                  <span className="text-muted-foreground">{pain}</span>
                </div>
                <div className="flex gap-2 text-xs">
                  <Check className="w-3.5 h-3.5 text-green-400 shrink-0 mt-0.5" />
                  <span className="text-muted-foreground">{gain}</span>
                </div>
              </div>
              <blockquote className="text-xs italic text-muted-foreground border-l-2 pl-3 mt-auto"
                style={{ borderColor: color }}>
                "{quote}"
              </blockquote>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

// ─── CTA ──────────────────────────────────────────────────────────────────────
function CTA() {
  const { isAuthenticated } = useAuth();
  return (
    <section className="py-24 relative overflow-hidden">
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute inset-0"
          style={{ background: "radial-gradient(ellipse at 50% 50%, oklch(0.62 0.22 270 / 0.12) 0%, transparent 70%)" }} />
      </div>
      <div className="container relative z-10 text-center">
        <div className="max-w-3xl mx-auto glass rounded-3xl border border-primary/20 p-12 glow-purple">
          <div className="w-16 h-16 rounded-2xl bg-primary/15 border border-primary/30 flex items-center justify-center mx-auto mb-6">
            <Zap className="w-8 h-8 text-primary" />
          </div>
          <h2 className="text-4xl sm:text-5xl font-bold text-white mb-4">
            Your next GTM brief is{" "}
            <span className="text-gradient font-serif italic">30 seconds away</span>
          </h2>
          <p className="text-lg text-muted-foreground mb-8">
            Stop spending days on strategy that should take seconds. Signal gives you the GTM brief your product deserves — right now.
          </p>
          <a href={isAuthenticated ? "/app" : getLoginUrl()}>
            <Button size="lg" className="bg-primary hover:bg-primary/90 text-white gap-2 px-10 py-6 text-base">
              <Zap className="w-5 h-5" />
              Generate My First GTM Brief
              <ArrowRight className="w-4 h-4" />
            </Button>
          </a>
          <p className="text-sm text-muted-foreground mt-4 flex items-center justify-center gap-2">
            <Lock className="w-3.5 h-3.5" />
            Free to start · No credit card required · Instant results
          </p>
        </div>
      </div>
    </section>
  );
}

// ─── Footer ───────────────────────────────────────────────────────────────────
function Footer() {
  return (
    <footer className="border-t border-white/6 py-10">
      <div className="container flex flex-col sm:flex-row items-center justify-between gap-4">
        <div className="flex items-center gap-2">
          <div className="w-6 h-6 rounded-md bg-primary/80 flex items-center justify-center">
            <Zap className="w-3.5 h-3.5 text-white" />
          </div>
          <span className="text-sm font-semibold text-white">Signal</span>
          <span className="text-sm text-muted-foreground">— AI-Powered GTM Intelligence</span>
        </div>
        <p className="text-xs text-muted-foreground">
          © {new Date().getFullYear()} Signal. Built for product marketers who move fast.
        </p>
      </div>
    </footer>
  );
}

// ─── Page ─────────────────────────────────────────────────────────────────────
export default function Home() {
  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <Hero />
      <Problem />
      <Features />
      <Roadmap />
      <Compare />
      <Personas />
      <CTA />
      <Footer />
    </div>
  );
}
